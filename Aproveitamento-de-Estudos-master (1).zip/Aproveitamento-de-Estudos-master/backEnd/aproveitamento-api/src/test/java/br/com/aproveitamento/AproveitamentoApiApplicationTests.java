package br.com.aproveitamento;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AproveitamentoApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
