export interface Curso {
    id: string;
    nome: string;
    coordenadores: any;
    ppcs: any;
    alunos: any;
}
