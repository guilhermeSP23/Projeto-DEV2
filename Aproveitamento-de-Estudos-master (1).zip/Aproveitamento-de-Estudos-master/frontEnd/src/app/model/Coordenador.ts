export interface Coordenador {
    id: string;
    nome: string
    ativo: boolean;
}
