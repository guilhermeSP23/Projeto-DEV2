export interface Usuario {
    id: string,
    nome: string;
    email: string;
    admin: boolean;
    tipo: string;
}
