export interface Analise {
  id: string;
  status: string;
  parecer: string;
  servidor_id?: number;
  requisicao_id?: number;
  servidorNome?: string;
}
