export interface Servidor {
    id: string,
    nome: string;
    email: string;
    admin: boolean;
    tipo: string;
    siape: string;
  }
  