export interface Discipline {
    id: string;
    nome: string;
    codDisciplina: number;
    cargaHoraria: number;
    ppc: any;
    requisicoes: any;
}
