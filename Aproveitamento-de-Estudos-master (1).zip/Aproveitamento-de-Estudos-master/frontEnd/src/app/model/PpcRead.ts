export interface PpcRead {
  id: string;
  curso_id: number;
  nomePPC: string;
  ano: number;
  nomeCurso: string;
}
