export interface Etapa {
  id: string;
  nome: string;
  ator: string;
  dataInicio: string;
  dataFim: string;
}
