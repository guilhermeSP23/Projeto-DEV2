export interface Coordinator {
  id: string;
  dataInicio: string;
  dataFim: string;
  nome: string;
}
