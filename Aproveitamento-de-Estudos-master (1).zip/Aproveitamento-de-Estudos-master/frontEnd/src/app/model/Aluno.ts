export interface Aluno {
  id: string;
  nome: string;
  email: string;
  admin: boolean;
  tipo: string;
  matricula: string;
  dataIngresso: string;
  curso: any;
}
