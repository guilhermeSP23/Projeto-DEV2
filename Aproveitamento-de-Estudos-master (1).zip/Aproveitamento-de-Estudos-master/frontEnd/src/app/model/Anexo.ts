export interface Anexo {
  id: string;
  nome: string;
  arquivo: string;
  requisicao: number;
}
