export interface PpcCreate {
  id: string;
  curso_id: number;
  nomePPC: string;
  ano: number;
}
